package com.wipro.SB2.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;

import com.wipro.SB2.Movie;
import com.wipro.SB2.dao.MovieDao;

@Controller
public class AdminController {
    private static final String ADMIN_EMAIL = "stella@gmail.com";
    private static final String ADMIN_PASSWORD = "stellar";
    @Autowired
    MovieDao dao;

    @RequestMapping("/admin")
    public String showLoginPage() {
        return "AdminHome";
    }

    @PostMapping("/login")
    public String login(@RequestParam("email") String email, @RequestParam("password") String password) {
        if (email.equals(ADMIN_EMAIL) && password.equals(ADMIN_PASSWORD)) {
            return "admin";
        } else {
            return "InvalidAdmin";
        }
    }
    @RequestMapping("/add")
    public String showAddMoviePage() {
        return "Addmovie"; 
    }

    @PostMapping("/addmovie")
    public String addMovie(@RequestParam String movieId, @RequestParam String movieName, @RequestParam int collection) {
        Movie movie = new Movie(movieId, movieName, collection);
        dao.save(movie);
        return "Successfull";
    }
    @RequestMapping("/modify")
    public String showModifyPage() {
        return "modifyAdminPage";
    }
}
