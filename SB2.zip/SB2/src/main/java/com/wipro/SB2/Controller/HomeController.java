package com.wipro.SB2.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.wipro.SB2.Movie;
import com.wipro.SB2.dao.MovieDao;
import com.wipro.SB2.sevice.MovieServiceImp;

@Controller
public class HomeController {
	@Autowired
	MovieDao dao;
	@RequestMapping("/")
	public String home() {
		return "Home";
	}
	@GetMapping("/get")
	public String getId() {
		return "getId";
	}
	@PostMapping("/getp")
    public String searchById(@RequestParam String movieId, Model model) {
        Optional<Movie> movie = dao.findById(movieId);
        if (movie.isPresent()) {
            model.addAttribute("movie", movie.get());
            System.out.println(dao.findById(movieId).toString());
            return "MovieDetails"; // Assume movie_details.html is the movie details page template
        } else {
            return "error"; // Assume error.html is the error page template
        }
    }
	

		@Autowired
		MovieServiceImp movieService;
	    @GetMapping("/getname")
	    public String getMovieByNameForm() {
	        return "GetName";
	    }

//	    @PostMapping("/byname")
//	    public String getMovieByName(@RequestParam("movieName") String movieName, Model model) {
//	        List<Movie> movies = movieService.getMoviesByName(movieName);
//	        if (!movies.isEmpty()) {
//	            model.addAttribute("movies", movies);
//	            return "movie-details";
//	        } else {
//	            return "error";
//	        }
//	    }
	    @RequestMapping("/byname")
	    public String searchByMovieName(@RequestParam("movieName") String movieName, Model model) {
	        List<Movie> matchingMovies = movieService.searchByMovieName(movieName);
	        model.addAttribute("matchingMovies", matchingMovies);
	        return "search";
	    }

	    @GetMapping("/getcollection")
	    public String getMovieByCollectionForm() {
	        return "getCollections";
	    }
//
	    @RequestMapping("/bycollection")
	    public String searchByCollection(@RequestParam("minCollection") int minCollection,
                @RequestParam("maxCollection") int maxCollection,
                Model model) {
List<Movie> movies = movieService.getMoviesByCollectionRange(minCollection, maxCollection);

if (!movies.isEmpty()) {
model.addAttribute("movies", movies);
return "getSearch";
} else {
return "error";
}
}

	}


//    @GetMapping("/byName")
//    public String searchByName(@RequestParam String movieName, Model model) {
//        List<Movie> movies = dao.findByMovieNameContainingIgnoreCase(movieName);
//        if (!movies.isEmpty()) {
//            model.addAttribute("movies", movies);
//            return "movie_list"; // Assume movie_list.html is the movie list page template
//        } else {
//            return "error"; // Assume error.html is the error page template
//        }
//    }
//
//    @GetMapping("/byCollection")
//    public String searchByCollection(@RequestParam int minCollection, @RequestParam int maxCollection, Model model) {
//        List<Movie> movies = movieRepository.findByCollectionBetween(minCollection, maxCollection);
//        if (!movies.isEmpty()) {
//            model.addAttribute("movies", movies);
//            return "movie_list"; // Assume movie_list.html is the movie list page template
//        } else {
//            return "error"; // Assume error.html is the error page template
//        }
//    }


