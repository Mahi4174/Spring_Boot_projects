package com.wipro.SB2.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.wipro.SB2.Movie;

public interface MovieDao extends JpaRepository<Movie, String>{
	@Query("SELECT m FROM Movie m")
    List<Movie> getAllMovies();

	}

