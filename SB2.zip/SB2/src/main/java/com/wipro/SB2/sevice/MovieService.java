package com.wipro.SB2.sevice;

import java.util.List;

import com.wipro.SB2.Movie;

public interface MovieService {
    
    Movie getMovieById(String movieId);
    
    List<Movie> getMoviesByName(String movieName);
    
    List<Movie> getMoviesByCollectionRange(int minCollection, int maxCollection);
    
    void addMovie(Movie movie);


	List<Movie> searchByMovieName(String movieName);

	List<Movie> retrieveAllMovies();
}

