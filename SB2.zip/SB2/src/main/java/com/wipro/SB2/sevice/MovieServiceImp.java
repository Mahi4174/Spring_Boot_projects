package com.wipro.SB2.sevice;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.SB2.Movie;
import com.wipro.SB2.dao.MovieDao;

@Service
public class MovieServiceImp implements MovieService {

    @Autowired
    private MovieDao movieRepository;

    @Override
    public Movie getMovieById(String movieId) {
        return movieRepository.findById(movieId).orElse(null);
    }

    @Override
    public List<Movie> getMoviesByName(String movieName) {
        return null;
    }

    
    @Override
    public void addMovie(Movie movie) {
        movieRepository.save(movie);
    }

    @Override
    public List<Movie> retrieveAllMovies() {
        return movieRepository.getAllMovies();
    }

    @Override
    public List<Movie> searchByMovieName(String movieName) {
        List<Movie> allMovies = movieRepository.getAllMovies();
        List<Movie> matchingMovies = new ArrayList<>();

        for (Movie movie : allMovies) {
            if (movie.getMovieName().toLowerCase().contains(movieName.toLowerCase())) {
                matchingMovies.add(movie);
            }
        }

        return matchingMovies;
    }
    private List<Movie> movies;

    public void MovieService() {
        movies = new ArrayList<>(); // Initialize the movies list
    }
    public List<Movie> getMoviesByCollectionRange(int minCollection, int maxCollection) {
        List<Movie> result = new ArrayList<>();
        for (Movie movie : retrieveAllMovies()) {
            if (movie.getCollection() >= minCollection && movie.getCollection() <= maxCollection) {
                result.add(movie);
            }
        }
        return result;
    }

    

}
