package com.wipro.SBcar;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="NewCars")
public class Car {
	@Id
	private int id;
	private String brand;
    private String model;
    private int modelYear;
    private int kilometers;
    private int price;
    private String fuel;
	public Car() {
		super();
	}
	
	public Car(int id, String brand, String model, int modelYear, int kilometers, int price, String fuel) {
		super();
		this.id = id;
		this.brand = brand;
		this.model = model;
		this.modelYear = modelYear;
		this.kilometers = kilometers;
		this.price = price;
		this.fuel = fuel;
	}

	@Override
	public String toString() {
		return "Car [brand=" + brand + ", model=" + model + ", modelYear=" + modelYear + ", kilometers=" + kilometers
				+ ", price=" + price + ", fuel=" + fuel + "]";
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getModelYear() {
		return modelYear;
	}
	public void setModelYear(int modelYear) {
		this.modelYear = modelYear;
	}
	public int getKilometers() {
		return kilometers;
	}
	public void setKilometers(int kilometers) {
		this.kilometers = kilometers;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getFuel() {
		return fuel;
	}
	public void setFuel(String fuel) {
		this.fuel = fuel;
	}

}
