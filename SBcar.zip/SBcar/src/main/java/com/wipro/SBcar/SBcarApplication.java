package com.wipro.SBcar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SBcarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SBcarApplication.class, args);
	}

}
