package com.wipro.SBcar.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.wipro.SBcar.Car;
import com.wipro.SBcar.Dao.CarDao;
import com.wipro.SBcar.service.CarServiceImp;

@Controller
public class TestController {
	@Autowired
	CarDao dao;
	@Autowired
	CarServiceImp service;
	@RequestMapping("/")
	public String ind() {
		return "index";
	}
	@RequestMapping("/brand")
	public String bran() {
		return "SearchByBrand";
	}
	@RequestMapping("/price")
	public String price() {
		return "SearchByPrice";
	}
    public List<Car> getAllCars() {
        return dao.findAll();
    }
//   @RequestMapping("/getCarBrands")
//   public String getCarBrand() {
//	   
//   }
//    @GetMapping("/search")
//    public List<Car> searchCarsByBrand(@RequestParam("brand") String brand) {
//        return dao.findByBrand(brand);
//    }
    @PostMapping("/prices")
    public String getCarsByPriceRange(@RequestParam String value, Model model) {
        if (value.equals("less")) {
            List<Car> lessThanFiveLakhsCars = service.findCarsLessThanFiveLakhs();
            model.addAttribute("cars", lessThanFiveLakhsCars);
            System.out.println(lessThanFiveLakhsCars);
            return "carsless5";
        } else if (value.equals("greater")) {
            List<Car> greaterThanFiveLakhsCars = service.findCarsGreaterThanFiveLakhs();
            model.addAttribute("cars", greaterThanFiveLakhsCars);
            return "carsgreterthan5";
        }

        return "error";
    }
    @RequestMapping("/succes")
    public String showBookingSuccess() {
        return "success";
    }
    @PostMapping("/getCarBrands")
    public String getBrands(@RequestParam("brand") String brand,Model model) {
    	List<Car> getcars = dao.findByBrand(brand);
        model.addAttribute("cars",getcars);
    	return "SearchByBrandResults";
    }
    

}
