package com.wipro.SBcar.service;

import java.util.List;

import com.wipro.SBcar.Car;

public interface CarSer {
    List<Car> findCarsLessThanFiveLakhs();
    List<Car> findCarsGreaterThanFiveLakhs();
	List<Car> findByBrand(String brand);
}
