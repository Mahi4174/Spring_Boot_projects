package com.wipro.SBcar.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.wipro.SBcar.Car;
import com.wipro.SBcar.Dao.CarDao;

@Service
public class CarServiceImp implements CarSer{

//	    @Override
//	    public List<Car> findByBrand(String brand) {
//	        List<Car> result = new ArrayList<>();
//	        for (Car car : cars) {
//	            if (car.getBrand().equalsIgnoreCase(brand)) {
//	                result.add(car);
//	            }
//	        }
//	        return result;
//	    }
	private CarDao cardao;
	
	
	List<Car> c = new ArrayList<>();
	@Autowired
	    public CarServiceImp(CarDao cardao) {
		super();
		this.cardao = cardao;
		
	}

		@Override
	    public List<Car> findCarsLessThanFiveLakhs() {
			List<Car> result = cardao.findAll();
	        System.out.println(result);
	        
	        for (Car car : result) {
	            if (car.getPrice() < 500000) {
	                c.add(car);
	            }
	        }
	        return c;
	    }

	    @Override
	    public List<Car> findCarsGreaterThanFiveLakhs() {
	        List<Car> result = cardao.findAll();
	        System.out.println(result);
	        
	        for (Car car : result) {
	            if (car.getPrice() > 500000) {
	                c.add(car);
	            }
	        }
	        return c;
	    }
		@Override
		public List<Car> findByBrand(String brand) {
			// TODO Auto-generated method stub
			return null;
		}

//	    @Override
//	    public List<Car> findByBrand(String brand) {
//	        String query = "SELECT * FROM cars WHERE brand = ?";
//	        return JdbcTemplate.query(query, new Object[]{brand}, (resultSet, rowNum) -> {
//	            Car car = new Car();
//	            car.setId(resultSet.getInt("id"));
//	            car.setBrand(resultSet.getString("brand"));
//	            car.setModel(resultSet.getString("model"));
//	            car.setModelYear(resultSet.getInt("year"));
//	            car.setPrice(resultSet.getInt("price"));
//	            return car;
//	        });
//	    }
	    

	    // Implement other repository methods for creating, updating, and deleting cars
	

	
}
